import java.text.DecimalFormat;
import java.util.Scanner;

public class TaxCalculator {
    private static double basicRate = 0.04; // 4%
    private static double luxuryRate = 0.10; // 10%
    private static DecimalFormat decimalFormat = new DecimalFormat("#.###");

    public static double computeCostBasic(double price) {
        double cost = price + (price * basicRate);
        return roundToThreeSignificantFigures(cost);
    }

    public static double computeCostLuxury(double price) {
        double cost = price + (price * luxuryRate);
        return roundToThreeSignificantFigures(cost);
    }

    public static void changeBasicRateTo(double newRate) {
        if (newRate >= 4.0) {
            basicRate = newRate / 100.0;
        } else {
            System.out.println("Invalid basic tax rate! Rate cannot be less than 4%.");
            System.out.println("Please re-enter the basic tax rate:");
            Scanner scanner = new Scanner(System.in);
            double rate = scanner.nextDouble();
            changeBasicRateTo(rate);
        }
    }

    public static void changeLuxuryRateTo(double newRate) {
        if (newRate >= 10.0) {
            luxuryRate = newRate / 100.0;
        } else {
            System.out.println("Invalid luxury tax rate! Rate cannot be less than 10%.");
            System.out.println("Please re-enter the luxury tax rate:");
            Scanner scanner = new Scanner(System.in);
            double rate = scanner.nextDouble();
            changeLuxuryRateTo(rate);
        }
    }

    public static double roundToThreeSignificantFigures(double value) {
        if (value == 0.0) {
            return 0.0;
        }

        final double magnitude = Math.pow(10, Math.floor(Math.log10(Math.abs(value))) + 1 - 3);
        return Double.parseDouble(decimalFormat.format(value / magnitude)) * magnitude;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the item price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume the remaining newline character

        System.out.print("Enter the basic tax rate (%), or enter 'n/a' if not applicable: ");
        String basicTaxRateInput = scanner.nextLine().trim();
        if (!basicTaxRateInput.equalsIgnoreCase("n/a")) {
            try {
                double basicTaxRate = Double.parseDouble(basicTaxRateInput);
                if (basicTaxRate >= 4.0) {
                    changeBasicRateTo(basicTaxRate);
                    System.out.println("Basic Tax: $" + decimalFormat.format(price * basicRate));
                } else {
                    System.out.println("Invalid basic tax rate! Rate cannot be less than 4%.");
                    System.out.println("Please re-enter the basic tax rate:");
                    double rate = scanner.nextDouble();
                    changeBasicRateTo(rate);
                    System.out.println("Basic Tax: $" + decimalFormat.format(price * basicRate));
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input for basic tax rate! Skipping...");
            }
        } else {
            System.out.println("Basic Tax: n/a");
        }

        System.out.print("Enter the luxury tax rate (%), or enter 'n/a' if not applicable: ");
        String luxuryTaxRateInput = scanner.nextLine().trim();
        if (!luxuryTaxRateInput.equalsIgnoreCase("n/a")) {
            try {
                double luxuryTaxRate = Double.parseDouble(luxuryTaxRateInput);
                if (luxuryTaxRate >= 10.0) {
                    changeLuxuryRateTo(luxuryTaxRate);
                    System.out.println("Luxury Tax: $" + decimalFormat.format(price * luxuryRate));
                } else {
                    System.out.println("Invalid luxury tax rate! Rate cannot be less than 10%.");
                    System.out.println("Please re-enter the luxury tax rate:");
                    double rate = scanner.nextDouble();
                    changeLuxuryRateTo(rate);
                    System.out.println("Luxury Tax: $" + decimalFormat.format(price * luxuryRate));
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input for luxury tax rate! Skipping...");
            }
        } else {
            System.out.println("Luxury Tax: n/a");
        }

        System.out.println("Total Cost with Basic Tax: $" + decimalFormat.format(computeCostBasic(price)));
        System.out.println("Total Cost with Luxury Tax: $" + decimalFormat.format(computeCostLuxury(price)));

        scanner.close();
    }
}
