import java.util.Scanner;

public class StudentRecord {
    private double quiz1;
    private double quiz2;
    private double quiz3;
    private int midterm;
    private int finalExam;
    private double overallGrade;
    private String letterGrade;

    public void readInput() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the score for Quiz 1 (out of 10): ");
        setQuiz1(validateScore(scanner));

        System.out.print("Enter the score for Quiz 2 (out of 10): ");
        setQuiz2(validateScore(scanner));

        System.out.print("Enter the score for Quiz 3 (out of 10): ");
        setQuiz3(validateScore(scanner));

        System.out.println("Enter the score for the midterm exam (out of 100):");
        setMidterm(validateExamScore(scanner));

        System.out.println("Enter the score for the final exam (out of 100):");
        setFinal(validateExamScore(scanner));

        scanner.close();
    }

    private double validateScore(Scanner scanner) {
        double score;

        while (true) {
            if (scanner.hasNextDouble()) {
                score = scanner.nextDouble();
                if (score >= 0 && score <= 10) {
                    break;
                } else {
                    System.out.println("Invalid score. Please enter a score between 0 and 10:");
                }
            } else {
                System.out.println("Invalid input. Please enter a number:");
                scanner.next();
            }
        }

        return score;
    }

    private int validateExamScore(Scanner scanner) {
        int score;

        while (true) {
            if (scanner.hasNextInt()) {
                score = scanner.nextInt();
                if (score >= 0 && score <= 100) {
                    break;
                } else {
                    System.out.println("Invalid score. Please enter a score between 0 and 100:");
                }
            } else {
                System.out.println("Invalid input. Please enter a number:");
                scanner.next();
            }
        }

        return score;
    }

    public void writeOutput() {
        System.out.println("Quiz 1 Score: " + getQuiz1());
        System.out.println("Quiz 2 Score: " + getQuiz2());
        System.out.println("Quiz 3 Score: " + getQuiz3());
        System.out.println("Midterm Exam Score: " + getMidterm());
        System.out.println("Final Exam Score: " + getFinal());
        System.out.println("Overall Numeric Score: " + getOverallGrade());
        System.out.println("Final Letter Grade: " + getLetterGrade());
    }

    public double getQuiz1() {
        return quiz1;
    }

    public double getQuiz2() {
        return quiz2;
    }

    public double getQuiz3() {
        return quiz3;
    }

    public int getMidterm() {
        return midterm;
    }

    public int getFinal() {
        return finalExam;
    }

    public void setQuiz1(double quiz1) {
        this.quiz1 = quiz1;
    }

    public void setQuiz2(double quiz2) {
        this.quiz2 = quiz2;
    }

    public void setQuiz3(double quiz3) {
        this.quiz3 = quiz3;
    }

    public void setMidterm(int midterm) {
        this.midterm = midterm;
    }

    public void setFinal(int finalExam) {
        this.finalExam = finalExam;
    }

    public void computeNumericScore() {
        double quizPercentage = ((quiz1 + quiz2 + quiz3) / 30.0) * 0.25;
        double midtermPercentage = midterm / 100.0 * 0.35;
        double finalPercentage = finalExam / 100.0 * 0.4;
        overallGrade = (quizPercentage + midtermPercentage + finalPercentage) * 100.0;
    }

    public void computeLetterGrade() {
        if (overallGrade >= 90) {
            letterGrade = "A";
        } else if (overallGrade >= 80) {
            letterGrade = "B";
        } else if (overallGrade >= 70) {
            letterGrade = "C";
        } else if (overallGrade >= 60) {
            letterGrade = "D";
        } else {
            letterGrade = "F";
        }
    }

    public double getOverallGrade() {
        return overallGrade;
    }

    public String getLetterGrade() {
        return letterGrade;
    }

    public static void main(String[] args) {
        StudentRecord student = new StudentRecord();
        student.readInput();
        student.computeNumericScore();
        student.computeLetterGrade();
        student.writeOutput();
    }
}
