import java.util.Scanner;

public class Assingment_3_Task_1
{
	public static void main(String[] args) {
		System.out.println ("Enter data values for which to compute the geometric mean.");
		System.out.println ("Enter a negative number after you have entered all the data values.");
		Scanner sc = new Scanner (System.in);
		int count = 0;
		double ans = 1, value = 1;
		while (value > 0) {
		    value = sc.nextDouble ();
		    if (value > 0) {
		        ans *= value;
		        count++;
		    }
		}
		System.out.println ("The geometric mean is " + Math.pow (ans, 1.0 / count));
	} 
}